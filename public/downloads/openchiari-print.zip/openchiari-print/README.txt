Open Chiari: 3D-printable midline plaques

Two plaques of the midline view, skull base to upper neck, life size (about 150 x 120 mm, 12 mm thick):
openchiari-midline-typical.stl (typical anatomy) and openchiari-midline-chiari.stl (Chiari I). Lay them side by side.
Bone stands 1.5 mm proud, spinal fluid spaces are 2 mm deep, soft tissue 0.8 mm, brain and spinal cord flush,
and the McRae line (across the opening at the base of the skull) is a groove.

Printing: lay each plaque flat, face up; no supports needed. 0.2 mm layers work; a light-colored filament shows the
relief best. They also scale down well (for example 60%) for a smaller, cheaper print.

Illustration, not a medical image. Tonsils shown at their lowest point, where MRI measures them. Not medical advice. Talk to your doctor about your own care.

3D model by Open Chiari, CC BY-SA 4.0, adapted from Z-Anatomy (CC BY-SA 4.0) and BodyParts3D, © The Database Center for Life Science (CC BY-SA 2.1 JP).
Made by model/simple/build.mjs --print, from the same shapes as the 3D Explorer. https://openchiari.org/model/
